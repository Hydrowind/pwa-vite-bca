<script setup>
import Dialog from './components/DialogForm.vue'
</script>

<template>
  <Dialog />
</template>